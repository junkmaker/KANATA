// Main app entry
(function(){
  const { useState, useEffect, useMemo } = React;

  const DEFAULT_STATE = {
    selected: ['AAPL'],
    timeframe: '1D',
    compareMode: 'percent',
    activeTool: 'pan',
    drawings: [],
    showVolume: true,
    showFinancial: true,
    indicators: {
      sma5: false,
      sma25: true,
      sma75: true,
      ema20: false,
      boll: false,
      stoch: true,
      psar: false,
      ichi: false,
    },
    financial: { roe: true, roic: true, per: true },
  };

  function loadState(){
    try {
      const s = localStorage.getItem('stockchart.state');
      if (s) return {...DEFAULT_STATE, ...JSON.parse(s)};
    } catch {}
    return DEFAULT_STATE;
  }

  function App(){
    const [state, setState] = useState(loadState);
    const [tweaksOpen, setTweaksOpen] = useState(false);
    const [aesthetic, setAesthetic] = useState(() => {
      try { return localStorage.getItem('stockchart.aesthetic') || 'dark-blue'; } catch { return 'dark-blue'; }
    });
    const [density, setDensity] = useState(() => {
      try { return localStorage.getItem('stockchart.density') || 'comfortable'; } catch { return 'comfortable'; }
    });

    const { TICKERS, DATA, TF, retime } = window.APP_DATA;

    // Re-timed data per timeframe (times only — for labels)
    const data = useMemo(() => {
      const d = {};
      const tfMs = TF[state.timeframe] || TF['1D'];
      TICKERS.forEach(t => { d[t.code] = retime(DATA[t.code], tfMs); });
      return d;
    }, [state.timeframe]);

    useEffect(() => {
      try { localStorage.setItem('stockchart.state', JSON.stringify(state)); } catch {}
    }, [state]);
    useEffect(() => {
      try { localStorage.setItem('stockchart.aesthetic', aesthetic); } catch {}
      document.documentElement.dataset.aesthetic = aesthetic;
    }, [aesthetic]);
    useEffect(() => {
      try { localStorage.setItem('stockchart.density', density); } catch {}
      document.documentElement.dataset.density = density;
    }, [density]);

    // Tweaks wiring
    useEffect(() => {
      const onMsg = (e) => {
        if (!e.data || typeof e.data !== 'object') return;
        if (e.data.type === '__activate_edit_mode') setTweaksOpen(true);
        else if (e.data.type === '__deactivate_edit_mode') setTweaksOpen(false);
      };
      window.addEventListener('message', onMsg);
      window.parent.postMessage({type:'__edit_mode_available'}, '*');
      return () => window.removeEventListener('message', onMsg);
    }, []);

    const primary = state.selected[0];
    const primaryTicker = TICKERS.find(t => t.code === primary);
    const primarySeries = data[primary];
    const last = primarySeries[primarySeries.length - 1];
    const prev = primarySeries[primarySeries.length - 2];
    const chg = last.c - prev.c;
    const chgPct = chg/prev.c * 100;
    const up = chg >= 0;

    return React.createElement('div', {className:'app'},
      React.createElement(TopBar, {state, setState, primaryTicker, last, chg, chgPct, up}),
      React.createElement('div', {className:'main-grid'},
        React.createElement(window.LeftPanel, {state, setState}),
        React.createElement('div', {className:'chart-area'},
          React.createElement(window.Chart, {state, setState, tickers: TICKERS, data})
        ),
        React.createElement(window.RightPanel, {state, setState, tickers: TICKERS, data})
      ),
      React.createElement(StatusBar, {state, primaryTicker, last}),
      tweaksOpen && React.createElement(TweaksPanel, {aesthetic, setAesthetic, density, setDensity, onClose: () => setTweaksOpen(false), state, setState})
    );
  }

  function TopBar({state, setState, primaryTicker, last, chg, chgPct, up}){
    const marketTime = new Date().toLocaleTimeString('en-GB', {hour12:false});
    return React.createElement('header', {className:'topbar'},
      React.createElement('div', {className:'brand'},
        React.createElement('div', {className:'brand-mark'},
          React.createElement('svg', {width:20, height:20, viewBox:'0 0 20 20'},
            React.createElement('rect', {x:1, y:11, width:3, height:8, fill:'currentColor'}),
            React.createElement('rect', {x:6, y:6, width:3, height:13, fill:'currentColor'}),
            React.createElement('rect', {x:11, y:9, width:3, height:10, fill:'currentColor'}),
            React.createElement('rect', {x:16, y:2, width:3, height:17, fill:'currentColor'}),
          )
        ),
        React.createElement('div', {className:'brand-text'},
          React.createElement('div', {className:'brand-name'}, 'KAIROS /TERMINAL'),
          React.createElement('div', {className:'brand-sub'}, 'chart · v0.4.1')
        )
      ),
      primaryTicker && React.createElement('div', {className:'top-ticker'},
        React.createElement('div', {className:'tt-code'}, primaryTicker.code,
          React.createElement('span', {className:'tt-mkt'}, primaryTicker.market)
        ),
        React.createElement('div', {className:'tt-name'}, primaryTicker.name),
        React.createElement('div', {className:'tt-price ' + (up?'up':'down')}, window.FMT.fmtPrice(last.c, primaryTicker.currency)),
        React.createElement('div', {className:'tt-chg ' + (up?'up':'down')},
          (up?'▲ ':'▼ ') + (up?'+':'')+chg.toFixed(2) + ' (' + (up?'+':'')+chgPct.toFixed(2)+'%)'
        ),
      ),
      React.createElement('div', {className:'top-controls'},
        React.createElement('div', {className:'status-dot', title:'Live'}),
        React.createElement('span', {className:'status-text'}, 'LIVE'),
        React.createElement('span', {className:'clock'}, marketTime + ' JST'),
      )
    );
  }

  function StatusBar({state, primaryTicker, last}){
    return React.createElement('footer', {className:'statusbar'},
      React.createElement('span', null, 'TF ', React.createElement('b', null, state.timeframe)),
      React.createElement('span', null, 'SYM ', React.createElement('b', null, state.selected.join(' · '))),
      React.createElement('span', null, 'TOOL ', React.createElement('b', null, state.activeTool.toUpperCase())),
      React.createElement('span', null, 'DRAW ', React.createElement('b', null, state.drawings.length)),
      React.createElement('span', {style:{marginLeft:'auto'}}, 'Drag to pan · scroll to zoom · double-click row to set primary'),
    );
  }

  function TweaksPanel({aesthetic, setAesthetic, density, setDensity, onClose, state, setState}){
    return React.createElement('div', {className:'tweaks-panel'},
      React.createElement('div', {className:'tweaks-head'},
        React.createElement('span', null, 'TWEAKS'),
        React.createElement('button', {className:'link-btn', onClick: onClose}, 'CLOSE')
      ),
      React.createElement('div', {className:'tweaks-row'},
        React.createElement('div', {className:'tweak-label'}, 'Color theme'),
        React.createElement('div', {className:'tweak-chips'},
          [
            ['dark-blue','Dark Blue'],
            ['dark-neutral','Neutral'],
            ['dark-amber','Amber CRT'],
            ['midnight','Midnight'],
          ].map(([id, label]) => React.createElement('button', {
            key:id, className:'chip' + (aesthetic===id ? ' on' : ''), onClick: () => setAesthetic(id)
          }, label))
        )
      ),
      React.createElement('div', {className:'tweaks-row'},
        React.createElement('div', {className:'tweak-label'}, 'Density'),
        React.createElement('div', {className:'tweak-chips'},
          ['compact','comfortable'].map(d => React.createElement('button', {
            key:d, className:'chip' + (density===d ? ' on' : ''), onClick: () => setDensity(d)
          }, d))
        )
      ),
      React.createElement('div', {className:'tweaks-row'},
        React.createElement('div', {className:'tweak-label'}, 'Compare mode'),
        React.createElement('div', {className:'tweak-chips'},
          [['percent','% change'],['none','Hide compares']].map(([id,label]) => React.createElement('button', {
            key:id, className:'chip' + (state.compareMode===id ? ' on' : ''),
            onClick: () => setState(s => ({...s, compareMode: id}))
          }, label))
        )
      ),
      React.createElement('div', {className:'tweaks-row'},
        React.createElement('div', {className:'tweak-label'}, 'Quick presets'),
        React.createElement('div', {className:'tweak-chips'},
          React.createElement('button', {className:'chip', onClick: () => setState(s => ({...s, indicators: {sma5:false,sma25:true,sma75:true,ema20:false,boll:true,stoch:true,psar:false,ichi:false}}))}, 'Swing trader'),
          React.createElement('button', {className:'chip', onClick: () => setState(s => ({...s, indicators: {sma5:true,sma25:false,sma75:false,ema20:true,boll:false,stoch:true,psar:true,ichi:false}}))}, 'Day trader'),
          React.createElement('button', {className:'chip', onClick: () => setState(s => ({...s, indicators: {sma5:false,sma25:false,sma75:false,ema20:false,boll:false,stoch:false,psar:false,ichi:true}}))}, 'Ichimoku'),
          React.createElement('button', {className:'chip', onClick: () => setState(s => ({...s, indicators: {sma5:false,sma25:false,sma75:false,ema20:false,boll:false,stoch:false,psar:false,ichi:false}}))}, 'Clean'),
        )
      ),
    );
  }

  const root = ReactDOM.createRoot(document.getElementById('root'));
  root.render(React.createElement(App));
})();
