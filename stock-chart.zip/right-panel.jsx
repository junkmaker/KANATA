// Right panel: ticker list, search, fundamentals card
(function(){
  const { useState, useMemo } = React;

  function RightPanel({state, setState, tickers, data}){
    const [q, setQ] = useState('');
    const [marketFilter, setMarketFilter] = useState('ALL');

    const filtered = useMemo(() => {
      const ql = q.toLowerCase().trim();
      return tickers.filter(t => {
        if (marketFilter !== 'ALL' && t.market !== marketFilter) return false;
        if (!ql) return true;
        return t.code.toLowerCase().includes(ql) || t.name.toLowerCase().includes(ql) || t.sector.toLowerCase().includes(ql);
      });
    }, [tickers, q, marketFilter]);

    const toggle = (code) => {
      setState(s => {
        const sel = s.selected.includes(code)
          ? s.selected.filter(c => c !== code)
          : [...s.selected, code];
        // ensure at least one selected
        if (sel.length === 0) return s;
        if (sel.length > 6) sel.shift();
        return {...s, selected: sel};
      });
    };
    const makePrimary = (code) => {
      setState(s => {
        const rest = s.selected.filter(c => c !== code);
        return {...s, selected: [code, ...rest]};
      });
    };

    const primary = state.selected[0];
    const primaryTicker = tickers.find(t => t.code === primary);
    const primarySeries = data[primary];
    const last = primarySeries[primarySeries.length - 1];
    const prev = primarySeries[primarySeries.length - 2];
    const chg = last.c - prev.c;
    const chgPct = chg/prev.c * 100;

    return React.createElement('aside', {className:'panel panel-right'},
      // Search & filter
      React.createElement('div', {className:'section'},
        React.createElement('div', {className:'section-head'}, React.createElement('span', null, 'WATCHLIST'), React.createElement('span', {className:'hint'}, state.selected.length + ' selected')),
        React.createElement('div', {className:'search-row'},
          React.createElement('input', {
            className:'search-input',
            placeholder:'Search code or name…',
            value: q, onChange: e => setQ(e.target.value)
          })
        ),
        React.createElement('div', {className:'market-tabs'},
          ['ALL','JP','US'].map(m => React.createElement('button', {
            key: m,
            className:'mkt-tab' + (marketFilter===m ? ' active':''),
            onClick: () => setMarketFilter(m)
          }, m))
        )
      ),

      // Ticker list
      React.createElement('div', {className:'ticker-list'},
        filtered.map(t => {
          const series = data[t.code];
          const ll = series[series.length-1];
          const pp = series[series.length-2];
          const c = ll.c - pp.c;
          const cp = c/pp.c*100;
          const selIdx = state.selected.indexOf(t.code);
          const selected = selIdx >= 0;
          const isPrimary = selIdx === 0;
          const color = selected && !isPrimary ? window.COMPARE_COLORS[selIdx % window.COMPARE_COLORS.length] : null;
          // sparkline
          const spark = series.slice(-40);
          let min = Infinity, max = -Infinity;
          spark.forEach(b => { if (b.c < min) min = b.c; if (b.c > max) max = b.c; });
          const pts = spark.map((b, i) => {
            const x = (i/(spark.length-1)) * 52;
            const y = 14 - ((b.c - min)/(max-min+1e-9)) * 12;
            return x.toFixed(1)+','+y.toFixed(1);
          }).join(' ');
          return React.createElement('div', {
              key: t.code,
              className:'ticker-row' + (selected ? ' selected' : '') + (isPrimary ? ' primary' : ''),
              onClick: () => toggle(t.code),
              onDoubleClick: () => makePrimary(t.code)
            },
            React.createElement('div', {className:'tick-left'},
              React.createElement('div', {className:'tick-chk', style: selected && color ? {background: color, borderColor: color} : {}},
                isPrimary ? '●' : (selected ? selIdx+1 : '')
              ),
              React.createElement('div', {className:'tick-meta'},
                React.createElement('div', {className:'tick-code'}, t.code, React.createElement('span', {className:'tick-mkt'}, t.market)),
                React.createElement('div', {className:'tick-name'}, t.name),
              )
            ),
            React.createElement('div', {className:'tick-mid'},
              React.createElement('svg', {width:54, height:16, viewBox:'0 0 52 14', className:'spark'},
                React.createElement('polyline', {points: pts, fill:'none', stroke: c >= 0 ? 'var(--bull)' : 'var(--bear)', strokeWidth:1})
              )
            ),
            React.createElement('div', {className:'tick-right'},
              React.createElement('div', {className:'tick-price'}, window.FMT.fmtPrice(ll.c, t.currency)),
              React.createElement('div', {className:'tick-chg ' + (c>=0?'up':'down')}, (c>=0?'+':'')+cp.toFixed(2)+'%')
            )
          );
        })
      ),

      // Primary ticker fundamentals
      primaryTicker && React.createElement('div', {className:'section fundamentals'},
        React.createElement('div', {className:'section-head'}, React.createElement('span', null, 'FUNDAMENTALS'), React.createElement('span', {className:'hint'}, primaryTicker.code)),
        React.createElement('div', {className:'fund-grid'},
          React.createElement(Metric, {label:'ROE', value: primaryTicker.fin.roe.toFixed(1)+'%', color:'var(--lime)'}),
          React.createElement(Metric, {label:'ROIC', value: primaryTicker.fin.roic.toFixed(1)+'%', color:'var(--teal)'}),
          React.createElement(Metric, {label:'PER', value: primaryTicker.fin.per.toFixed(1)+'×', color:'var(--amber)'}),
          React.createElement(Metric, {label:'PBR', value: primaryTicker.fin.pbr.toFixed(2)+'×'}),
          React.createElement(Metric, {label:'DIV', value: primaryTicker.fin.div.toFixed(1)+'%'}),
          React.createElement(Metric, {label:'MCAP', value: primaryTicker.fin.mcap}),
        ),
        React.createElement('div', {className:'sector'},
          React.createElement('span', {className:'label'}, 'SECTOR'),
          React.createElement('span', null, primaryTicker.sector)
        )
      )
    );
  }

  function Metric({label, value, color}){
    return React.createElement('div', {className:'metric'},
      React.createElement('div', {className:'m-label'}, label),
      React.createElement('div', {className:'m-value', style: color ? {color} : {}}, value),
    );
  }

  window.RightPanel = RightPanel;
})();
