// Left panel: drawing tools, indicators, financial toggles
(function(){
  const { useState } = React;

  function Section({title, children, right}){
    return React.createElement('div', {className:'section'},
      React.createElement('div', {className:'section-head'},
        React.createElement('span', null, title),
        right
      ),
      React.createElement('div', {className:'section-body'}, children)
    );
  }

  function ToolBtn({id, label, icon, activeTool, setTool}){
    const active = activeTool === id;
    return React.createElement('button', {
      className: 'tool-btn' + (active ? ' active' : ''),
      onClick: () => setTool(id),
      title: label
    },
      React.createElement('span', {className:'tool-icon', dangerouslySetInnerHTML:{__html: icon}}),
      React.createElement('span', {className:'tool-label'}, label)
    );
  }

  function Toggle({label, value, onChange, color}){
    return React.createElement('label', {className:'toggle-row' + (value ? ' on' : '')},
      React.createElement('span', {className:'toggle-dot', style:{background: value ? (color || 'var(--accent)') : 'transparent', borderColor: color || 'var(--accent)'}}),
      React.createElement('span', {className:'toggle-label'}, label),
      React.createElement('input', {type:'checkbox', checked: value, onChange: e => onChange(e.target.checked), style:{display:'none'}})
    );
  }

  function LeftPanel({state, setState}){
    const setTool = (t) => setState(s => ({...s, activeTool: s.activeTool === t ? 'pan' : t}));
    const setInd = (k, v) => setState(s => ({...s, indicators: {...s.indicators, [k]: v}}));
    const setFin = (k, v) => setState(s => ({...s, financial: {...s.financial, [k]: v}}));

    const tools = [
      {id:'pan', label:'Pan / select', icon:'<svg viewBox="0 0 16 16" width="14" height="14" fill="none" stroke="currentColor" stroke-width="1.3"><path d="M3 8h10M8 3v10"/></svg>'},
      {id:'trend', label:'Trendline', icon:'<svg viewBox="0 0 16 16" width="14" height="14" fill="none" stroke="currentColor" stroke-width="1.3"><path d="M2 13L14 3"/><circle cx="2" cy="13" r="1.4" fill="currentColor"/><circle cx="14" cy="3" r="1.4" fill="currentColor"/></svg>'},
      {id:'hline', label:'Horizontal', icon:'<svg viewBox="0 0 16 16" width="14" height="14" fill="none" stroke="currentColor" stroke-width="1.3" stroke-dasharray="2 2"><path d="M1 8h14"/></svg>'},
      {id:'vline', label:'Vertical', icon:'<svg viewBox="0 0 16 16" width="14" height="14" fill="none" stroke="currentColor" stroke-width="1.3" stroke-dasharray="2 2"><path d="M8 1v14"/></svg>'},
      {id:'rect', label:'Rectangle', icon:'<svg viewBox="0 0 16 16" width="14" height="14" fill="none" stroke="currentColor" stroke-width="1.3"><rect x="2" y="4" width="12" height="8"/></svg>'},
      {id:'ellipse', label:'Ellipse', icon:'<svg viewBox="0 0 16 16" width="14" height="14" fill="none" stroke="currentColor" stroke-width="1.3"><ellipse cx="8" cy="8" rx="6" ry="4"/></svg>'},
      {id:'text', label:'Text note', icon:'<svg viewBox="0 0 16 16" width="14" height="14" fill="none" stroke="currentColor" stroke-width="1.3"><path d="M3 4h10M8 4v9M6 13h4"/></svg>'},
    ];

    const timeframes = ['5m','15m','60m','1D','1W','1M'];

    const clearDrawings = () => setState(s => ({...s, drawings: []}));

    return React.createElement('aside', {className:'panel panel-left'},
      // Timeframe
      React.createElement(Section, {title:'TIMEFRAME'},
        React.createElement('div', {className:'tf-grid'},
          timeframes.map(tf => React.createElement('button', {
            key: tf,
            className: 'tf-btn' + (state.timeframe === tf ? ' active' : ''),
            onClick: () => setState(s => ({...s, timeframe: tf}))
          }, tf))
        )
      ),

      // Drawing tools
      React.createElement(Section, {
          title:'DRAWING TOOLS',
          right: React.createElement('button', {className:'link-btn', onClick: clearDrawings, title:'Clear all drawings'}, 'CLEAR')
        },
        React.createElement('div', {className:'tool-grid'},
          tools.map(t => React.createElement(ToolBtn, {key: t.id, ...t, activeTool: state.activeTool, setTool}))
        ),
        state.drawings.length > 0 && React.createElement('div', {className:'drawing-count'},
          state.drawings.length + ' object' + (state.drawings.length===1?'':'s') + ' on chart'
        )
      ),

      // Technical indicators
      React.createElement(Section, {title:'TECHNICAL ANALYSIS'},
        React.createElement('div', {className:'subheader'}, 'Moving averages'),
        React.createElement(Toggle, {label:'SMA 5', value: state.indicators.sma5, onChange: v => setInd('sma5', v), color:'var(--amber)'}),
        React.createElement(Toggle, {label:'SMA 25', value: state.indicators.sma25, onChange: v => setInd('sma25', v), color:'var(--accent)'}),
        React.createElement(Toggle, {label:'SMA 75', value: state.indicators.sma75, onChange: v => setInd('sma75', v), color:'var(--magenta)'}),
        React.createElement(Toggle, {label:'EMA 20', value: state.indicators.ema20, onChange: v => setInd('ema20', v), color:'var(--lime)'}),
        React.createElement('div', {className:'subheader'}, 'Overlays'),
        React.createElement(Toggle, {label:'Bollinger Bands 20,2', value: state.indicators.boll, onChange: v => setInd('boll', v), color:'oklch(0.75 0.07 220)'}),
        React.createElement(Toggle, {label:'Parabolic SAR', value: state.indicators.psar, onChange: v => setInd('psar', v), color:'oklch(0.78 0.20 350)'}),
        React.createElement(Toggle, {label:'Ichimoku (一目均衡表)', value: state.indicators.ichi, onChange: v => setInd('ichi', v), color:'var(--magenta)'}),
        React.createElement('div', {className:'subheader'}, 'Oscillator'),
        React.createElement(Toggle, {label:'Stochastics 14,3,3', value: state.indicators.stoch, onChange: v => setInd('stoch', v), color:'var(--accent)'}),
      ),

      // Financial metrics
      React.createElement(Section, {title:'FUNDAMENTALS'},
        React.createElement(Toggle, {label:'Show fundamentals pane', value: state.showFinancial, onChange: v => setState(s => ({...s, showFinancial: v})), color:'var(--lime)'}),
        state.showFinancial && React.createElement('div', {style:{marginTop:6}},
          React.createElement(Toggle, {label:'ROE (%)', value: state.financial.roe, onChange: v => setFin('roe', v), color:'var(--lime)'}),
          React.createElement(Toggle, {label:'ROIC (%)', value: state.financial.roic, onChange: v => setFin('roic', v), color:'var(--teal)'}),
          React.createElement(Toggle, {label:'PER (×)', value: state.financial.per, onChange: v => setFin('per', v), color:'var(--amber)'}),
        )
      ),

      // Volume toggle
      React.createElement(Section, {title:'VOLUME'},
        React.createElement(Toggle, {label:'Show volume', value: state.showVolume, onChange: v => setState(s => ({...s, showVolume: v})), color:'var(--muted)'}),
      ),
    );
  }

  window.LeftPanel = LeftPanel;
})();
