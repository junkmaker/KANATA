// Technical indicators

(function(){
  function SMA(data, period, field='c'){
    const out = new Array(data.length).fill(null);
    let sum = 0;
    for (let i = 0; i < data.length; i++){
      sum += data[i][field];
      if (i >= period) sum -= data[i-period][field];
      if (i >= period-1) out[i] = sum / period;
    }
    return out;
  }
  function EMA(data, period, field='c'){
    const out = new Array(data.length).fill(null);
    const k = 2/(period+1);
    let prev = null;
    for (let i = 0; i < data.length; i++){
      const v = data[i][field];
      if (prev == null){
        if (i === period-1){
          let s = 0;
          for (let j = 0; j <= i; j++) s += data[j][field];
          prev = s/period;
          out[i] = prev;
        }
      } else {
        prev = v*k + prev*(1-k);
        out[i] = prev;
      }
    }
    return out;
  }

  function BOLL(data, period=20, mult=2){
    const mid = SMA(data, period);
    const upper = new Array(data.length).fill(null);
    const lower = new Array(data.length).fill(null);
    for (let i = period-1; i < data.length; i++){
      let s = 0;
      for (let j = i-period+1; j <= i; j++) s += Math.pow(data[j].c - mid[i], 2);
      const sd = Math.sqrt(s/period);
      upper[i] = mid[i] + mult*sd;
      lower[i] = mid[i] - mult*sd;
    }
    return {mid, upper, lower};
  }

  function STOCH(data, kPeriod=14, dPeriod=3, slowing=3){
    const rawK = new Array(data.length).fill(null);
    for (let i = kPeriod-1; i < data.length; i++){
      let hh = -Infinity, ll = Infinity;
      for (let j = i-kPeriod+1; j <= i; j++){
        if (data[j].h > hh) hh = data[j].h;
        if (data[j].l < ll) ll = data[j].l;
      }
      rawK[i] = (data[i].c - ll)/(hh - ll + 1e-9) * 100;
    }
    // slowed %K
    const k = new Array(data.length).fill(null);
    for (let i = 0; i < data.length; i++){
      if (i >= kPeriod-1+slowing-1){
        let s = 0, n = 0;
        for (let j = i-slowing+1; j <= i; j++){
          if (rawK[j] != null){ s += rawK[j]; n++; }
        }
        if (n === slowing) k[i] = s/slowing;
      }
    }
    const d = new Array(data.length).fill(null);
    for (let i = 0; i < data.length; i++){
      if (k[i] != null && i >= kPeriod-1+slowing-1+dPeriod-1){
        let s = 0;
        for (let j = i-dPeriod+1; j <= i; j++) s += k[j];
        d[i] = s/dPeriod;
      }
    }
    return {k, d};
  }

  function PSAR(data, step=0.02, maxStep=0.2){
    const out = new Array(data.length).fill(null);
    if (data.length < 2) return out;
    let uptrend = data[1].c > data[0].c;
    let af = step;
    let ep = uptrend ? data[0].h : data[0].l;
    let sar = uptrend ? data[0].l : data[0].h;
    out[0] = sar;
    for (let i = 1; i < data.length; i++){
      sar = sar + af * (ep - sar);
      const bar = data[i];
      if (uptrend){
        sar = Math.min(sar, data[i-1].l, i>=2 ? data[i-2].l : data[i-1].l);
        if (bar.l < sar){
          uptrend = false;
          sar = ep;
          ep = bar.l;
          af = step;
        } else {
          if (bar.h > ep){ ep = bar.h; af = Math.min(maxStep, af+step); }
        }
      } else {
        sar = Math.max(sar, data[i-1].h, i>=2 ? data[i-2].h : data[i-1].h);
        if (bar.h > sar){
          uptrend = true;
          sar = ep;
          ep = bar.h;
          af = step;
        } else {
          if (bar.l < ep){ ep = bar.l; af = Math.min(maxStep, af+step); }
        }
      }
      out[i] = sar;
    }
    return out;
  }

  // Ichimoku: Tenkan(9), Kijun(26), Senkou A/B (shift 26 forward), Chikou (shift 26 back)
  function ICHI(data, tenkanP=9, kijunP=26, senkouBP=52, disp=26){
    const n = data.length;
    const hh = (i,p) => { let h=-Infinity; for (let j=i-p+1; j<=i; j++) if (data[j].h>h) h=data[j].h; return h; };
    const ll = (i,p) => { let l=Infinity; for (let j=i-p+1; j<=i; j++) if (data[j].l<l) l=data[j].l; return l; };
    const tenkan = new Array(n).fill(null);
    const kijun = new Array(n).fill(null);
    const senkouA = new Array(n + disp).fill(null);
    const senkouB = new Array(n + disp).fill(null);
    const chikou = new Array(n).fill(null);
    for (let i = 0; i < n; i++){
      if (i >= tenkanP-1) tenkan[i] = (hh(i,tenkanP) + ll(i,tenkanP))/2;
      if (i >= kijunP-1) kijun[i] = (hh(i,kijunP) + ll(i,kijunP))/2;
      if (tenkan[i] != null && kijun[i] != null) senkouA[i + disp] = (tenkan[i]+kijun[i])/2;
      if (i >= senkouBP-1) senkouB[i + disp] = (hh(i,senkouBP) + ll(i,senkouBP))/2;
      if (i - disp >= 0) chikou[i - disp] = data[i].c;
    }
    return {tenkan, kijun, senkouA, senkouB, chikou};
  }

  window.IND = { SMA, EMA, BOLL, STOCH, PSAR, ICHI };
})();
