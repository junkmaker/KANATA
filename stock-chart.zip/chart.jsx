// Chart rendering on canvas
(function(){
  const { useRef, useEffect, useState, useMemo, useCallback } = React;

  // Color palette
  const COLORS = {
    bg: 'oklch(0.16 0.005 250)',
    panel: 'oklch(0.185 0.006 250)',
    grid: 'oklch(0.24 0.006 250)',
    gridSoft: 'oklch(0.21 0.006 250)',
    text: 'oklch(0.88 0.005 250)',
    muted: 'oklch(0.55 0.005 250)',
    bull: 'oklch(0.82 0.13 150)',
    bear: 'oklch(0.78 0.15 22)',
    accent: 'oklch(0.78 0.14 220)',
    amber: 'oklch(0.80 0.15 85)',
    magenta: 'oklch(0.72 0.18 330)',
    lime: 'oklch(0.85 0.18 120)',
    violet: 'oklch(0.72 0.16 290)',
    teal: 'oklch(0.76 0.11 180)',
    cloudGreen: 'oklch(0.82 0.13 150 / 0.20)',
    cloudRed: 'oklch(0.78 0.15 22 / 0.20)',
  };

  const COMPARE_COLORS = [
    'oklch(0.78 0.14 220)',
    'oklch(0.80 0.15 85)',
    'oklch(0.72 0.18 330)',
    'oklch(0.85 0.18 120)',
    'oklch(0.72 0.16 290)',
    'oklch(0.76 0.11 180)',
  ];

  function fmtPrice(v, cur='$'){
    if (v == null || isNaN(v)) return '—';
    if (cur === '¥') return cur + Math.round(v).toLocaleString();
    return cur + v.toFixed(2);
  }
  function fmtVol(v){
    if (v >= 1e9) return (v/1e9).toFixed(2)+'B';
    if (v >= 1e6) return (v/1e6).toFixed(2)+'M';
    if (v >= 1e3) return (v/1e3).toFixed(1)+'K';
    return String(v);
  }
  function fmtDate(t, tf){
    const d = new Date(t);
    if (tf === '5m' || tf === '15m' || tf === '60m'){
      return d.toLocaleString('en-GB', {month:'short', day:'2-digit', hour:'2-digit', minute:'2-digit', hour12:false});
    }
    return d.toLocaleDateString('en-GB', {year:'2-digit', month:'short', day:'2-digit'});
  }

  // Custom hook: observe element size
  function useSize(ref){
    const [size, setSize] = useState({w: 0, h: 0});
    useEffect(() => {
      if (!ref.current) return;
      const ro = new ResizeObserver(entries => {
        for (const e of entries){
          const cr = e.contentRect;
          setSize({w: cr.width, h: cr.height});
        }
      });
      ro.observe(ref.current);
      return () => ro.disconnect();
    }, [ref]);
    return size;
  }

  // Draw candlesticks
  function drawCandles(ctx, bars, xScale, yScale, bw){
    const bodyW = Math.max(1, bw * 0.72);
    for (let i = 0; i < bars.length; i++){
      const b = bars[i];
      const x = xScale(i);
      const up = b.c >= b.o;
      ctx.strokeStyle = up ? COLORS.bull : COLORS.bear;
      ctx.fillStyle = up ? COLORS.bull : COLORS.bear;
      ctx.lineWidth = 1;
      // wick
      ctx.beginPath();
      ctx.moveTo(Math.round(x)+0.5, yScale(b.h));
      ctx.lineTo(Math.round(x)+0.5, yScale(b.l));
      ctx.stroke();
      // body
      const yo = yScale(b.o);
      const yc = yScale(b.c);
      const top = Math.min(yo, yc);
      const h = Math.max(1, Math.abs(yc - yo));
      ctx.fillRect(Math.round(x - bodyW/2), Math.round(top), Math.round(bodyW), Math.round(h));
    }
  }

  function drawLine(ctx, xs, ys, color, width=1.25, dash=null){
    ctx.strokeStyle = color;
    ctx.lineWidth = width;
    if (dash) ctx.setLineDash(dash); else ctx.setLineDash([]);
    ctx.beginPath();
    let started = false;
    for (let i = 0; i < ys.length; i++){
      if (ys[i] == null){ started = false; continue; }
      const x = xs(i), y = ys[i];
      if (!started){ ctx.moveTo(x, y); started = true; }
      else ctx.lineTo(x, y);
    }
    ctx.stroke();
    ctx.setLineDash([]);
  }

  // Main chart component
  function Chart({state, setState, tickers, data}){
    const wrapRef = useRef(null);
    const canvasRef = useRef(null);
    const overlayRef = useRef(null);
    const size = useSize(wrapRef);

    const primary = state.selected[0];
    const primaryData = data[primary];

    // Compute visible range
    const [view, setView] = useState({start: 1200, end: 1500}); // index range into primaryData
    // When primary changes, reset view
    useEffect(() => {
      if (!primaryData) return;
      const end = primaryData.length;
      const start = Math.max(0, end - 220);
      setView({start, end});
    }, [primary]);

    const visibleBars = primaryData ? primaryData.slice(view.start, view.end) : [];

    // Price pane geometry
    const PAD_L = 12, PAD_R = 72, PAD_T = 12;
    const VOL_H = state.showVolume ? 64 : 0;
    const STOCH_H = state.indicators.stoch ? 72 : 0;
    const FIN_H = state.showFinancial ? 96 : 0;
    const X_AXIS_H = 22;
    const priceH = Math.max(120, size.h - VOL_H - STOCH_H - FIN_H - X_AXIS_H - PAD_T);
    const priceW = size.w - PAD_L - PAD_R;

    // Calc indicators for primary
    const indi = useMemo(() => {
      if (!primaryData) return {};
      const o = {};
      if (state.indicators.sma5) o.sma5 = IND.SMA(primaryData, 5);
      if (state.indicators.sma25) o.sma25 = IND.SMA(primaryData, 25);
      if (state.indicators.sma75) o.sma75 = IND.SMA(primaryData, 75);
      if (state.indicators.ema20) o.ema20 = IND.EMA(primaryData, 20);
      if (state.indicators.boll) o.boll = IND.BOLL(primaryData, 20, 2);
      if (state.indicators.stoch) o.stoch = IND.STOCH(primaryData, 14, 3, 3);
      if (state.indicators.psar) o.psar = IND.PSAR(primaryData);
      if (state.indicators.ichi) o.ichi = IND.ICHI(primaryData);
      return o;
    }, [primaryData, state.indicators]);

    // y-axis range over visible
    const yRange = useMemo(() => {
      if (!primaryData) return {min: 0, max: 1};
      let min = Infinity, max = -Infinity;
      for (let i = view.start; i < view.end; i++){
        const b = primaryData[i];
        if (b.h > max) max = b.h;
        if (b.l < min) min = b.l;
      }
      if (state.indicators.boll && indi.boll){
        for (let i = view.start; i < view.end; i++){
          if (indi.boll.upper[i] != null && indi.boll.upper[i] > max) max = indi.boll.upper[i];
          if (indi.boll.lower[i] != null && indi.boll.lower[i] < min) min = indi.boll.lower[i];
        }
      }
      // Include comparison lines (normalized)
      const pad = (max - min) * 0.08;
      return {min: min - pad, max: max + pad};
    }, [primaryData, view, state.indicators.boll, indi]);

    // Scales
    const nVis = view.end - view.start;
    const bw = priceW / nVis;
    const xScale = (i) => PAD_L + (i - view.start) * bw + bw/2;
    const yScale = (v) => {
      const t = (v - yRange.min) / (yRange.max - yRange.min);
      return PAD_T + (1 - t) * priceH;
    };

    // Volume scale
    let volMax = 1;
    for (let i = view.start; i < view.end; i++) if (primaryData && primaryData[i].v > volMax) volMax = primaryData[i].v;
    const volY0 = PAD_T + priceH + 4;
    const volYScale = (v) => volY0 + VOL_H - (v/volMax)*VOL_H + 4;

    // Stoch scale
    const stochY0 = volY0 + VOL_H + 18;
    const stochYScale = (v) => stochY0 + (1 - v/100) * (STOCH_H - 4);

    // Financial scale
    const finY0 = stochY0 + STOCH_H + 18;

    // Draw
    useEffect(() => {
      const cvs = canvasRef.current;
      if (!cvs || !primaryData || !size.w) return;
      const dpr = window.devicePixelRatio || 1;
      cvs.width = size.w * dpr;
      cvs.height = size.h * dpr;
      cvs.style.width = size.w + 'px';
      cvs.style.height = size.h + 'px';
      const ctx = cvs.getContext('2d');
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      ctx.clearRect(0, 0, size.w, size.h);

      // Grid: price pane
      ctx.font = '11px "JetBrains Mono", monospace';
      ctx.textBaseline = 'middle';
      ctx.fillStyle = COLORS.muted;
      // horizontal grid lines
      const nLines = 6;
      for (let i = 0; i <= nLines; i++){
        const y = PAD_T + (priceH / nLines) * i;
        ctx.strokeStyle = i === 0 || i === nLines ? COLORS.grid : COLORS.gridSoft;
        ctx.beginPath();
        ctx.moveTo(PAD_L, Math.round(y)+0.5);
        ctx.lineTo(PAD_L + priceW, Math.round(y)+0.5);
        ctx.stroke();
        const v = yRange.max - (yRange.max - yRange.min) * (i/nLines);
        ctx.textAlign = 'left';
        const tk = tickers.find(t => t.code === primary);
        ctx.fillText(fmtPrice(v, tk?.currency || '$'), PAD_L + priceW + 6, y);
      }

      // Vertical gridlines at nice intervals
      const tickStep = Math.max(1, Math.floor(nVis / 10));
      ctx.strokeStyle = COLORS.gridSoft;
      ctx.fillStyle = COLORS.muted;
      ctx.textAlign = 'center';
      const tf = state.timeframe;
      for (let i = view.start; i < view.end; i += tickStep){
        const x = xScale(i);
        ctx.beginPath();
        ctx.moveTo(Math.round(x)+0.5, PAD_T);
        ctx.lineTo(Math.round(x)+0.5, PAD_T + priceH + VOL_H + STOCH_H + (state.showVolume?4:0) + (state.indicators.stoch?18:0));
        ctx.stroke();
      }

      // Ichimoku cloud first (behind candles)
      if (state.indicators.ichi && indi.ichi){
        const {tenkan, kijun, senkouA, senkouB, chikou} = indi.ichi;
        // Draw cloud polygon between A and B in visible range (A/B are shifted forward by 26)
        ctx.beginPath();
        let first = true;
        for (let i = view.start; i < view.end; i++){
          if (senkouA[i] == null || senkouB[i] == null) continue;
          const x = xScale(i);
          if (first){ ctx.moveTo(x, yScale(senkouA[i])); first = false; }
          else ctx.lineTo(x, yScale(senkouA[i]));
        }
        for (let i = view.end - 1; i >= view.start; i--){
          if (senkouA[i] == null || senkouB[i] == null) continue;
          const x = xScale(i);
          ctx.lineTo(x, yScale(senkouB[i]));
        }
        ctx.closePath();
        // Split cloud color by sign at center sample
        const midI = Math.floor((view.start + view.end)/2);
        const green = (senkouA[midI] ?? 0) >= (senkouB[midI] ?? 0);
        ctx.fillStyle = green ? COLORS.cloudGreen : COLORS.cloudRed;
        ctx.fill();
        drawLine(ctx, xScale, tenkan, COLORS.magenta, 1.25);
        drawLine(ctx, xScale, kijun, COLORS.accent, 1.25);
        drawLine(ctx, xScale, chikou, COLORS.muted, 1, [4,3]);
      }

      // Bollinger
      if (state.indicators.boll && indi.boll){
        drawLine(ctx, xScale, indi.boll.upper, 'oklch(0.75 0.07 220 / 0.85)', 1);
        drawLine(ctx, xScale, indi.boll.mid, 'oklch(0.70 0.05 220 / 0.7)', 1, [3,3]);
        drawLine(ctx, xScale, indi.boll.lower, 'oklch(0.75 0.07 220 / 0.85)', 1);
      }

      // Candles for primary
      const visArr = primaryData;
      ctx.save();
      ctx.beginPath();
      ctx.rect(PAD_L, PAD_T, priceW, priceH);
      ctx.clip();
      for (let i = view.start; i < view.end; i++){
        const b = visArr[i];
        const x = xScale(i);
        const up = b.c >= b.o;
        ctx.strokeStyle = up ? COLORS.bull : COLORS.bear;
        ctx.fillStyle = up ? COLORS.bull : COLORS.bear;
        // wick
        ctx.beginPath();
        ctx.moveTo(Math.round(x)+0.5, yScale(b.h));
        ctx.lineTo(Math.round(x)+0.5, yScale(b.l));
        ctx.stroke();
        const yo = yScale(b.o);
        const yc = yScale(b.c);
        const top = Math.min(yo, yc);
        const h = Math.max(1, Math.abs(yc - yo));
        const bodyW = Math.max(1, bw * 0.72);
        if (up){
          // hollow body for bull (terminal style)
          ctx.fillStyle = 'oklch(0.82 0.13 150 / 0.30)';
          ctx.fillRect(Math.round(x - bodyW/2), Math.round(top), Math.round(bodyW), Math.round(h));
          ctx.strokeRect(Math.round(x - bodyW/2)+0.5, Math.round(top)+0.5, Math.round(bodyW)-1, Math.round(h)-1);
        } else {
          ctx.fillRect(Math.round(x - bodyW/2), Math.round(top), Math.round(bodyW), Math.round(h));
        }
      }

      // SMA/EMA
      if (state.indicators.sma5 && indi.sma5) drawLine(ctx, xScale, indi.sma5, COLORS.amber, 1.25);
      if (state.indicators.sma25 && indi.sma25) drawLine(ctx, xScale, indi.sma25, COLORS.accent, 1.25);
      if (state.indicators.sma75 && indi.sma75) drawLine(ctx, xScale, indi.sma75, COLORS.magenta, 1.25);
      if (state.indicators.ema20 && indi.ema20) drawLine(ctx, xScale, indi.ema20, COLORS.lime, 1.25, [4,2]);

      // PSAR dots
      if (state.indicators.psar && indi.psar){
        ctx.fillStyle = 'oklch(0.78 0.20 350)';
        for (let i = view.start; i < view.end; i++){
          if (indi.psar[i] == null) continue;
          const x = xScale(i), y = yScale(indi.psar[i]);
          ctx.beginPath();
          ctx.arc(x, y, 1.6, 0, Math.PI*2);
          ctx.fill();
        }
      }
      ctx.restore();

      // Comparison: additional selected tickers drawn as normalized lines
      if (state.selected.length > 1 && state.compareMode === 'percent'){
        // draw a secondary y axis for percent change from start of view
        for (let idx = 1; idx < state.selected.length; idx++){
          const code = state.selected[idx];
          const arr = data[code];
          if (!arr) continue;
          const color = COMPARE_COLORS[idx % COMPARE_COLORS.length];
          // align end-of-data to primary end-of-view, step backwards
          const off = arr.length - primaryData.length;
          const basePrice = arr[Math.max(0, view.start + off)]?.c;
          if (!basePrice) continue;
          // build a percent series mapped to primary yRange: we use a secondary overlay scale
          // Determine min/max of secondary pct
          let pmin = Infinity, pmax = -Infinity;
          for (let i = view.start; i < view.end; i++){
            const bi = i + off;
            if (bi < 0 || bi >= arr.length) continue;
            const pct = (arr[bi].c/basePrice - 1)*100;
            if (pct < pmin) pmin = pct;
            if (pct > pmax) pmax = pct;
          }
          // Also consider primary percent range to share scale roughly
          const primBase = primaryData[view.start].c;
          for (let i = view.start; i < view.end; i++){
            const pct = (primaryData[i].c/primBase - 1)*100;
            if (pct < pmin) pmin = pct;
            if (pct > pmax) pmax = pct;
          }
          const pad2 = (pmax - pmin)*0.1 || 1;
          pmin -= pad2; pmax += pad2;
          // We'll draw only compare lines using this shared pct scale
          const pctY = (p) => PAD_T + (1 - (p - pmin)/(pmax - pmin)) * priceH;
          const ys = [];
          for (let i = 0; i < primaryData.length; i++){
            const bi = i + off;
            if (bi < 0 || bi >= arr.length) { ys.push(null); continue; }
            ys.push(pctY((arr[bi].c/basePrice - 1)*100));
          }
          ctx.save();
          ctx.beginPath();
          ctx.rect(PAD_L, PAD_T, priceW, priceH);
          ctx.clip();
          drawLine(ctx, xScale, ys, color, 1.5);
          ctx.restore();
        }
      }

      // Volume
      if (state.showVolume){
        ctx.fillStyle = COLORS.muted;
        ctx.textAlign = 'left';
        ctx.fillText('VOL', PAD_L, volY0 + 10);
        for (let i = view.start; i < view.end; i++){
          const b = primaryData[i];
          const up = b.c >= b.o;
          ctx.fillStyle = up ? 'oklch(0.86 0.12 150 / 0.70)' : 'oklch(0.82 0.14 22 / 0.70)';
          const x = xScale(i);
          const bodyW = Math.max(1, bw * 0.72);
          const hh = (b.v/volMax) * VOL_H;
          ctx.fillRect(Math.round(x - bodyW/2), Math.round(volY0 + VOL_H - hh + 4), Math.round(bodyW), Math.round(hh));
        }
        // top line
        ctx.strokeStyle = COLORS.grid;
        ctx.beginPath();
        ctx.moveTo(PAD_L, volY0+0.5);
        ctx.lineTo(PAD_L + priceW, volY0+0.5);
        ctx.stroke();
      }

      // Stochastics
      if (state.indicators.stoch && indi.stoch){
        ctx.fillStyle = COLORS.muted;
        ctx.textAlign = 'left';
        ctx.fillText('STOCH %K 14 %D 3', PAD_L, stochY0 - 6);
        // 20/80 lines
        ctx.strokeStyle = COLORS.gridSoft;
        [20, 50, 80].forEach(v => {
          const y = stochYScale(v);
          ctx.setLineDash(v === 50 ? [2,3] : []);
          ctx.beginPath();
          ctx.moveTo(PAD_L, y);
          ctx.lineTo(PAD_L + priceW, y);
          ctx.stroke();
          ctx.fillStyle = COLORS.muted;
          ctx.textAlign = 'left';
          ctx.fillText(String(v), PAD_L + priceW + 6, y);
        });
        ctx.setLineDash([]);
        const {k, d} = indi.stoch;
        drawLine(ctx, xScale, k.map(v => v==null?null:stochYScale(v)), COLORS.accent, 1.25);
        drawLine(ctx, xScale, d.map(v => v==null?null:stochYScale(v)), COLORS.amber, 1.25, [3,2]);
      }

      // Financial time series pane
      if (state.showFinancial){
        const finData = window.APP_DATA.FIN_TS[primary];
        const finW = priceW;
        const finY = finY0;
        // frame
        ctx.strokeStyle = COLORS.grid;
        ctx.beginPath();
        ctx.moveTo(PAD_L, finY+0.5);
        ctx.lineTo(PAD_L + finW, finY+0.5);
        ctx.stroke();

        ctx.fillStyle = COLORS.muted;
        ctx.textAlign = 'left';
        ctx.fillText('FUNDAMENTALS · last 20 quarters', PAD_L, finY - 6);

        // two y axes: left for ROE/ROIC (%), right for PER
        let rmin = Infinity, rmax = -Infinity;
        let pmin = Infinity, pmax = -Infinity;
        finData.forEach(f => {
          if (state.financial.roe){ if (f.roe < rmin) rmin = f.roe; if (f.roe > rmax) rmax = f.roe; }
          if (state.financial.roic){ if (f.roic < rmin) rmin = f.roic; if (f.roic > rmax) rmax = f.roic; }
          if (state.financial.per){ if (f.per < pmin) pmin = f.per; if (f.per > pmax) pmax = f.per; }
        });
        if (rmin === Infinity){ rmin = 0; rmax = 1; }
        if (pmin === Infinity){ pmin = 0; pmax = 1; }
        rmin -= (rmax-rmin)*0.1; rmax += (rmax-rmin)*0.1;
        pmin -= (pmax-pmin)*0.1; pmax += (pmax-pmin)*0.1;

        const fx = (i) => PAD_L + (i/(finData.length-1)) * finW;
        const fyL = (v) => finY + 8 + (1 - (v - rmin)/(rmax - rmin)) * (FIN_H - 20);
        const fyR = (v) => finY + 8 + (1 - (v - pmin)/(pmax - pmin)) * (FIN_H - 20);

        // axis ticks left
        ctx.fillStyle = COLORS.muted;
        ctx.textAlign = 'right';
        ctx.fillText(rmax.toFixed(1)+'%', PAD_L + finW + 56, finY + 12);
        ctx.fillText(rmin.toFixed(1)+'%', PAD_L + finW + 56, finY + FIN_H - 8);

        // Draw series
        const drawFin = (ys, color, dash) => {
          ctx.strokeStyle = color;
          ctx.lineWidth = 1.5;
          if (dash) ctx.setLineDash(dash); else ctx.setLineDash([]);
          ctx.beginPath();
          ys.forEach((y, i) => { if (i===0) ctx.moveTo(fx(i), y); else ctx.lineTo(fx(i), y); });
          ctx.stroke();
          ctx.setLineDash([]);
          // endpoint dot
          ctx.fillStyle = color;
          ctx.beginPath();
          ctx.arc(fx(finData.length-1), ys[ys.length-1], 2.5, 0, Math.PI*2);
          ctx.fill();
        };
        if (state.financial.roe) drawFin(finData.map(f => fyL(f.roe)), COLORS.lime);
        if (state.financial.roic) drawFin(finData.map(f => fyL(f.roic)), COLORS.teal);
        if (state.financial.per) drawFin(finData.map(f => fyR(f.per)), COLORS.amber, [4,2]);
      }

      // X axis date labels (bottom)
      const xAxisY = size.h - X_AXIS_H/2;
      ctx.fillStyle = COLORS.muted;
      ctx.textAlign = 'center';
      for (let i = view.start; i < view.end; i += tickStep){
        const x = xScale(i);
        ctx.fillText(fmtDate(primaryData[i].t, tf), x, xAxisY);
      }

    }, [size, primaryData, view, state, indi, tickers, primary, priceW, priceH]);

    // Overlay rendering: crosshair, drawings, hover legend
    const [hover, setHover] = useState(null);
    const [dragging, setDragging] = useState(null); // {type:'pan'|'drawing', ...}
    const [tempDrawing, setTempDrawing] = useState(null);

    // Convert screen to data coords
    const screenToData = useCallback((sx, sy) => {
      const idx = view.start + (sx - PAD_L) / bw;
      const v = yRange.max - ((sy - PAD_T)/priceH) * (yRange.max - yRange.min);
      return {idx, v};
    }, [view, bw, yRange, priceH]);
    const dataToScreen = useCallback((idx, v) => {
      return {x: xScale(idx), y: yScale(v)};
    }, [view, bw, yRange, priceH]);

    useEffect(() => {
      const cvs = overlayRef.current;
      if (!cvs) return;
      const dpr = window.devicePixelRatio || 1;
      cvs.width = size.w * dpr;
      cvs.height = size.h * dpr;
      cvs.style.width = size.w + 'px';
      cvs.style.height = size.h + 'px';
      const ctx = cvs.getContext('2d');
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      ctx.clearRect(0, 0, size.w, size.h);

      // Draw saved drawings
      const allDrawings = [...(state.drawings || []), ...(tempDrawing ? [tempDrawing] : [])];
      allDrawings.forEach(d => {
        if (d.ticker && d.ticker !== primary) return;
        ctx.strokeStyle = d.color || COLORS.accent;
        ctx.fillStyle = d.color || COLORS.accent;
        ctx.lineWidth = 1.5;
        if (d.type === 'hline'){
          const y = yScale(d.v);
          ctx.setLineDash([5,3]);
          ctx.beginPath();
          ctx.moveTo(PAD_L, y);
          ctx.lineTo(PAD_L + priceW, y);
          ctx.stroke();
          ctx.setLineDash([]);
          ctx.font = '10px "JetBrains Mono", monospace';
          const tk = tickers.find(t => t.code === primary);
          ctx.fillText(fmtPrice(d.v, tk?.currency || '$'), PAD_L + 4, y - 4);
        } else if (d.type === 'vline'){
          const x = xScale(d.idx);
          ctx.setLineDash([5,3]);
          ctx.beginPath();
          ctx.moveTo(x, PAD_T);
          ctx.lineTo(x, PAD_T + priceH);
          ctx.stroke();
          ctx.setLineDash([]);
        } else if (d.type === 'trend'){
          const p1 = dataToScreen(d.i1, d.v1);
          const p2 = dataToScreen(d.i2, d.v2);
          ctx.beginPath();
          ctx.moveTo(p1.x, p1.y);
          ctx.lineTo(p2.x, p2.y);
          ctx.stroke();
          ctx.beginPath(); ctx.arc(p1.x, p1.y, 3, 0, Math.PI*2); ctx.fill();
          ctx.beginPath(); ctx.arc(p2.x, p2.y, 3, 0, Math.PI*2); ctx.fill();
        } else if (d.type === 'rect'){
          const p1 = dataToScreen(d.i1, d.v1);
          const p2 = dataToScreen(d.i2, d.v2);
          ctx.fillStyle = (d.color || COLORS.accent).replace(')', ' / 0.12)').replace('oklch(', 'oklch(');
          ctx.fillRect(Math.min(p1.x,p2.x), Math.min(p1.y,p2.y), Math.abs(p2.x-p1.x), Math.abs(p2.y-p1.y));
          ctx.strokeRect(Math.min(p1.x,p2.x), Math.min(p1.y,p2.y), Math.abs(p2.x-p1.x), Math.abs(p2.y-p1.y));
        } else if (d.type === 'ellipse'){
          const p1 = dataToScreen(d.i1, d.v1);
          const p2 = dataToScreen(d.i2, d.v2);
          const cx = (p1.x+p2.x)/2, cy = (p1.y+p2.y)/2;
          const rx = Math.abs(p2.x-p1.x)/2, ry = Math.abs(p2.y-p1.y)/2;
          ctx.beginPath();
          ctx.ellipse(cx, cy, rx, ry, 0, 0, Math.PI*2);
          ctx.stroke();
        } else if (d.type === 'text'){
          const p = dataToScreen(d.idx, d.v);
          ctx.fillStyle = d.color || COLORS.accent;
          ctx.font = '11px "JetBrains Mono", monospace';
          ctx.textAlign = 'left';
          ctx.textBaseline = 'middle';
          ctx.fillText(d.text || '…', p.x + 6, p.y);
          ctx.beginPath(); ctx.arc(p.x, p.y, 3, 0, Math.PI*2); ctx.fill();
        }
      });

      // Crosshair & hover
      if (hover && hover.sx >= PAD_L && hover.sx <= PAD_L + priceW){
        ctx.strokeStyle = COLORS.muted;
        ctx.setLineDash([2,3]);
        ctx.beginPath();
        ctx.moveTo(Math.round(hover.sx)+0.5, PAD_T);
        ctx.lineTo(Math.round(hover.sx)+0.5, PAD_T + priceH + VOL_H + STOCH_H + (state.showVolume?4:0) + (state.indicators.stoch?18:0));
        ctx.stroke();
        if (hover.sy >= PAD_T && hover.sy <= PAD_T + priceH){
          ctx.beginPath();
          ctx.moveTo(PAD_L, Math.round(hover.sy)+0.5);
          ctx.lineTo(PAD_L + priceW, Math.round(hover.sy)+0.5);
          ctx.stroke();
        }
        ctx.setLineDash([]);

        // price label on right axis
        if (hover.sy >= PAD_T && hover.sy <= PAD_T + priceH){
          const v = yRange.max - ((hover.sy - PAD_T)/priceH) * (yRange.max - yRange.min);
          ctx.fillStyle = COLORS.panel;
          ctx.fillRect(PAD_L + priceW, hover.sy - 9, PAD_R - 2, 18);
          ctx.strokeStyle = COLORS.accent;
          ctx.strokeRect(PAD_L + priceW + 0.5, hover.sy - 9 + 0.5, PAD_R - 3, 17);
          ctx.fillStyle = COLORS.accent;
          ctx.textAlign = 'left';
          ctx.textBaseline = 'middle';
          const tk = tickers.find(t => t.code === primary);
          ctx.font = '11px "JetBrains Mono", monospace';
          ctx.fillText(fmtPrice(v, tk?.currency || '$'), PAD_L + priceW + 6, hover.sy);
        }

        // date label on bottom
        const idx = Math.round(view.start + (hover.sx - PAD_L) / bw);
        if (idx >= view.start && idx < view.end && primaryData[idx]){
          const xAxisY = size.h - X_AXIS_H/2;
          ctx.fillStyle = COLORS.panel;
          ctx.fillRect(hover.sx - 58, xAxisY - 9, 116, 18);
          ctx.strokeStyle = COLORS.accent;
          ctx.strokeRect(hover.sx - 58 + 0.5, xAxisY - 9 + 0.5, 115, 17);
          ctx.fillStyle = COLORS.accent;
          ctx.textAlign = 'center';
          ctx.textBaseline = 'middle';
          ctx.font = '11px "JetBrains Mono", monospace';
          ctx.fillText(fmtDate(primaryData[idx].t, state.timeframe), hover.sx, xAxisY);
        }
      }
    }, [hover, state.drawings, tempDrawing, yRange, view, primary, size, priceH, priceW]);

    // Pointer handling
    const onPointerDown = (e) => {
      const rect = e.currentTarget.getBoundingClientRect();
      const sx = e.clientX - rect.left;
      const sy = e.clientY - rect.top;
      const {idx, v} = screenToData(sx, sy);
      const tool = state.activeTool;
      if (tool === 'pan' || !tool){
        setDragging({type:'pan', startX: sx, startView: {...view}});
        e.currentTarget.setPointerCapture(e.pointerId);
      } else if (tool === 'hline'){
        setState(s => ({...s, drawings:[...s.drawings, {type:'hline', v, color: COLORS.amber, ticker: primary, id: Math.random()}], activeTool: 'pan'}));
      } else if (tool === 'vline'){
        setState(s => ({...s, drawings:[...s.drawings, {type:'vline', idx, color: COLORS.amber, ticker: primary, id: Math.random()}], activeTool: 'pan'}));
      } else if (tool === 'trend' || tool === 'rect' || tool === 'ellipse'){
        setTempDrawing({type: tool, i1: idx, v1: v, i2: idx, v2: v, color: COLORS.accent, ticker: primary, id: Math.random()});
        setDragging({type:'drawing'});
        e.currentTarget.setPointerCapture(e.pointerId);
      } else if (tool === 'text'){
        const txt = prompt('Annotation text:');
        if (txt){
          setState(s => ({...s, drawings:[...s.drawings, {type:'text', idx, v, text: txt, color: COLORS.accent, ticker: primary, id: Math.random()}], activeTool: 'pan'}));
        } else {
          setState(s => ({...s, activeTool: 'pan'}));
        }
      }
    };
    const onPointerMove = (e) => {
      const rect = e.currentTarget.getBoundingClientRect();
      const sx = e.clientX - rect.left;
      const sy = e.clientY - rect.top;
      setHover({sx, sy});
      if (dragging?.type === 'pan'){
        const dx = sx - dragging.startX;
        const shift = Math.round(-dx / bw);
        let ns = dragging.startView.start + shift;
        let ne = dragging.startView.end + shift;
        if (ns < 0){ ne -= ns; ns = 0; }
        if (ne > primaryData.length){ const d2 = ne - primaryData.length; ns -= d2; ne -= d2; }
        setView({start: ns, end: ne});
      } else if (dragging?.type === 'drawing' && tempDrawing){
        const {idx, v} = screenToData(sx, sy);
        setTempDrawing({...tempDrawing, i2: idx, v2: v});
      }
    };
    const onPointerUp = (e) => {
      if (dragging?.type === 'drawing' && tempDrawing){
        setState(s => ({...s, drawings: [...s.drawings, tempDrawing], activeTool: 'pan'}));
        setTempDrawing(null);
      }
      setDragging(null);
      try { e.currentTarget.releasePointerCapture(e.pointerId); } catch {}
    };
    const onWheel = (e) => {
      e.preventDefault();
      const rect = e.currentTarget.getBoundingClientRect();
      const sx = e.clientX - rect.left;
      const centerFrac = (sx - PAD_L)/priceW;
      const scale = e.deltaY > 0 ? 1.15 : 0.87;
      const len = view.end - view.start;
      let newLen = Math.max(30, Math.min(primaryData.length, Math.round(len * scale)));
      const center = view.start + centerFrac * len;
      let ns = Math.round(center - centerFrac * newLen);
      let ne = ns + newLen;
      if (ns < 0){ ne -= ns; ns = 0; }
      if (ne > primaryData.length){ const d2 = ne - primaryData.length; ns -= d2; ne -= d2; }
      setView({start: ns, end: ne});
    };

    // Hover info to display in legend
    const hoverIdx = hover ? Math.round(view.start + (hover.sx - PAD_L) / bw) : (view.end - 1);
    const hoverBar = primaryData && primaryData[hoverIdx];

    return React.createElement('div', {
        ref: wrapRef,
        className: 'chart-wrap',
        style: {position:'relative', width:'100%', height:'100%', cursor: state.activeTool && state.activeTool !== 'pan' ? 'crosshair' : (dragging?.type==='pan' ? 'grabbing' : 'crosshair')}
      },
      React.createElement('canvas', {ref: canvasRef, style:{position:'absolute', inset:0}}),
      React.createElement('canvas', {
        ref: overlayRef,
        style:{position:'absolute', inset:0},
        onPointerDown, onPointerMove, onPointerUp,
        onPointerLeave: () => setHover(null),
        onWheel
      }),
      // Top-left legend overlay
      React.createElement(ChartLegend, {state, hoverBar, tickers, primary, data, hoverIdx, yRange})
    );
  }

  function ChartLegend({state, hoverBar, tickers, primary, data, hoverIdx, yRange}){
    const tk = tickers.find(t => t.code === primary);
    if (!tk) return null;
    const last = hoverBar;
    if (!last) return null;
    const prev = data[primary][Math.max(0, hoverIdx - 1)];
    const chg = last.c - prev.c;
    const chgPct = chg/prev.c * 100;
    const up = chg >= 0;

    const rows = [];
    rows.push(React.createElement('div', {key:'sym', className:'legend-symbol'},
      React.createElement('span', {className:'sym-code'}, tk.code),
      React.createElement('span', {className:'sym-name'}, tk.name),
      React.createElement('span', {className:'sym-mkt'}, tk.market),
    ));
    rows.push(React.createElement('div', {key:'ohlc', className:'legend-ohlc'},
      React.createElement('span', null, 'O'), React.createElement('b', null, fmtPrice(last.o, tk.currency)),
      React.createElement('span', null, 'H'), React.createElement('b', null, fmtPrice(last.h, tk.currency)),
      React.createElement('span', null, 'L'), React.createElement('b', null, fmtPrice(last.l, tk.currency)),
      React.createElement('span', null, 'C'), React.createElement('b', {style:{color: up ? 'var(--bull)' : 'var(--bear)'}}, fmtPrice(last.c, tk.currency)),
      React.createElement('span', {style:{color: up ? 'var(--bull)' : 'var(--bear)'}}, (up?'+':'')+chg.toFixed(2)+' ('+(up?'+':'')+chgPct.toFixed(2)+'%)'),
      React.createElement('span', null, 'V'), React.createElement('b', null, fmtVol(last.v)),
    ));

    // Indicator values
    const indRows = [];
    const i = hoverIdx;
    if (state.indicators.sma5) indRows.push({label:'MA5', v: IND.SMA(data[primary], 5)[i], c:'var(--amber)'});
    if (state.indicators.sma25) indRows.push({label:'MA25', v: IND.SMA(data[primary], 25)[i], c:'var(--accent)'});
    if (state.indicators.sma75) indRows.push({label:'MA75', v: IND.SMA(data[primary], 75)[i], c:'var(--magenta)'});
    if (state.indicators.ema20) indRows.push({label:'EMA20', v: IND.EMA(data[primary], 20)[i], c:'var(--lime)'});
    if (state.indicators.boll){
      const b = IND.BOLL(data[primary], 20, 2);
      indRows.push({label:'BB', v: b.mid[i], extra: ` · U ${fmtPrice(b.upper[i], tk.currency)} · L ${fmtPrice(b.lower[i], tk.currency)}`, c:'oklch(0.75 0.07 220)'});
    }
    if (indRows.length){
      rows.push(React.createElement('div', {key:'ind', className:'legend-ind'},
        indRows.map((r, k) => React.createElement('span', {key:k, className:'ind-pill'},
          React.createElement('i', {style:{background:r.c}}),
          r.label, ' ', r.v != null ? fmtPrice(r.v, tk.currency) : '—', r.extra || ''
        ))
      ));
    }

    // Compare legend
    if (state.selected.length > 1){
      const comps = state.selected.slice(1).map((code, idx) => {
        const arr = data[code];
        const tk2 = tickers.find(t => t.code === code);
        if (!arr || !tk2) return null;
        return React.createElement('span', {key:code, className:'ind-pill'},
          React.createElement('i', {style:{background: COMPARE_COLORS[(idx+1) % COMPARE_COLORS.length]}}),
          tk2.code
        );
      });
      rows.push(React.createElement('div', {key:'cmp', className:'legend-ind'}, comps));
    }

    return React.createElement('div', {className:'chart-legend'}, rows);
  }

  window.Chart = Chart;
  window.CHART_COLORS = COLORS;
  window.COMPARE_COLORS = COMPARE_COLORS;
  window.FMT = { fmtPrice, fmtVol, fmtDate };
})();
